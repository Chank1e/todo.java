import java.text.ParseException;

public class Main {
    public static void main(String[] args) throws ParseException {
        List list = new List("BackLog");
        list.addTask(new Task("TaskName1","TaskDescription1"));
        list.addTask(new Task("TaskName2","TaskDescription2"));


        Task task1 = new Task();
        task1.setDeadline("22-04-2000");
        task1.setName("qq");
        task1.setDescription("qwwq");

        list.addTask(task1);
        list.setName("Before 2018");

        list.showTasks();

    }
}
